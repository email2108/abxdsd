// GLXD Shop Chat Socket.IO Configuration
import { Server, Socket } from 'socket.io'
import jwt from 'jsonwebtoken'
import { db } from './db'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

interface AuthenticatedSocket extends Socket {
  userId?: string
  userEmail?: string
  userRole?: string
}

export const setupSocket = (io: Server) => {
  // Authentication middleware
  io.use((socket: AuthenticatedSocket, next) => {
    const token = socket.handshake.auth.token || socket.handshake.headers.authorization

    if (!token) {
      return next(new Error('Authentication error'))
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; email: string; role: string }
      socket.userId = decoded.userId
      socket.userEmail = decoded.email
      socket.userRole = decoded.role
      next()
    } catch (err) {
      next(new Error('Authentication error'))
    }
  })

  io.on('connection', (socket: AuthenticatedSocket) => {
    console.log(`User connected: ${socket.userEmail} (${socket.userId})`)

    // Join user to their personal room
    socket.join(socket.userId!)

    // Update user online status
    if (socket.userId) {
      db.user.update({
        where: { id: socket.userId },
        data: { isOnline: true }
      }).catch(console.error)
    }

    // Broadcast user online status
    socket.broadcast.emit('user_online', {
      userId: socket.userId,
      userEmail: socket.userEmail
    })

    // Handle private messages
    socket.on('send_message', async (data: {
      receiverId: string
      content: string
    }) => {
      try {
        if (!socket.userId || !data.receiverId || !data.content) {
          socket.emit('error', { message: 'Invalid message data' })
          return
        }

        // Save message to database
        const message = await db.message.create({
          data: {
            content: data.content,
            senderId: socket.userId,
            receiverId: data.receiverId
          },
          include: {
            sender: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true
              }
            },
            receiver: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true
              }
            }
          }
        })

        // Send message to receiver
        io.to(data.receiverId).emit('new_message', message)
        
        // Send confirmation back to sender
        socket.emit('message_sent', message)

        // Emit to admin users for monitoring
        if (socket.userRole === 'ADMIN') {
          io.emit('admin_message', message)
        }

      } catch (error) {
        console.error('Message handling error:', error)
        socket.emit('error', { message: 'Failed to send message' })
      }
    })

    // Handle typing indicators
    socket.on('typing', (data: { receiverId: string }) => {
      socket.to(data.receiverId).emit('user_typing', {
        userId: socket.userId,
        userName: socket.userEmail
      })
    })

    socket.on('stop_typing', (data: { receiverId: string }) => {
      socket.to(data.receiverId).emit('user_stopped_typing', {
        userId: socket.userId
      })
    })

    // Handle read receipts
    socket.on('mark_as_read', (data: { messageId: string }) => {
      // You can implement read receipt logic here
      socket.emit('message_read', { messageId: data.messageId })
    })

    // Handle get online users
    socket.on('get_online_users', async () => {
      try {
        const onlineUsers = await db.user.findMany({
          where: { isOnline: true },
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            isOnline: true
          }
        })
        socket.emit('online_users', onlineUsers)
      } catch (error) {
        console.error('Get online users error:', error)
      }
    })

    // Handle disconnect
    socket.on('disconnect', async () => {
      console.log(`User disconnected: ${socket.userEmail} (${socket.userId})`)

      // Update user offline status
      if (socket.userId) {
        await db.user.update({
          where: { id: socket.userId },
          data: { isOnline: false }
        }).catch(console.error)
      }

      // Broadcast user offline status
      socket.broadcast.emit('user_offline', {
        userId: socket.userId,
        userEmail: socket.userEmail
      })
    })

    // Send welcome message
    socket.emit('connected', {
      message: 'Connected to GLXD Shop Chat',
      userId: socket.userId,
      userEmail: socket.userEmail
    })
  })
}