'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { Input } from '@/components/ui/input'
import { 
  MessageSquare, 
  Users, 
  Activity, 
  LogOut, 
  Search, 
  Eye,
  Trash2,
  Shield,
  Mail,
  Calendar
} from 'lucide-react'
import Link from 'next/link'

interface User {
  id: string
  name: string
  email: string
  role: 'USER' | 'ADMIN'
  isOnline: boolean
  createdAt: string
  avatar?: string
}

interface Message {
  id: string
  content: string
  senderId: string
  receiverId: string
  createdAt: string
  sender: User
  receiver: User
}

interface SystemStats {
  totalUsers: number
  onlineUsers: number
  totalMessages: number
  messagesToday: number
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [stats, setStats] = useState<SystemStats>({
    totalUsers: 0,
    onlineUsers: 0,
    totalMessages: 0,
    messagesToday: 0
  })
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    // Mock data for demo
    const mockUsers: User[] = [
      { id: '1', name: 'Nguyễn Văn A', email: 'user1@example.com', role: 'USER', isOnline: true, createdAt: '2024-01-10T10:30:00Z' },
      { id: '2', name: 'Trần Thị B', email: 'user2@example.com', role: 'USER', isOnline: true, createdAt: '2024-01-11T14:20:00Z' },
      { id: '3', name: 'Lê Văn C', email: 'user3@example.com', role: 'USER', isOnline: false, createdAt: '2024-01-12T09:15:00Z' },
      { id: '4', name: 'Admin User', email: 'admin@example.com', role: 'ADMIN', isOnline: true, createdAt: '2024-01-01T08:00:00Z' },
      { id: '5', name: 'Phạm Thị D', email: 'user4@example.com', role: 'USER', isOnline: true, createdAt: '2024-01-13T16:45:00Z' },
    ]
    setUsers(mockUsers)

    const mockMessages: Message[] = [
      {
        id: '1',
        content: 'Xin chào! Bạn có khỏe không?',
        senderId: '1',
        receiverId: '2',
        createdAt: '2024-01-15T10:30:00Z',
        sender: mockUsers[0],
        receiver: mockUsers[1]
      },
      {
        id: '2',
        content: 'Tôi khỏe, cảm ơn bạn!',
        senderId: '2',
        receiverId: '1',
        createdAt: '2024-01-15T10:32:00Z',
        sender: mockUsers[1],
        receiver: mockUsers[0]
      },
      {
        id: '3',
        content: 'Hôm nay bạn có kế hoạch gì không?',
        senderId: '1',
        receiverId: '2',
        createdAt: '2024-01-15T10:35:00Z',
        sender: mockUsers[0],
        receiver: mockUsers[1]
      },
      {
        id: '4',
        content: 'Cần hỗ trợ gì không?',
        senderId: '3',
        receiverId: '1',
        createdAt: '2024-01-15T11:20:00Z',
        sender: mockUsers[2],
        receiver: mockUsers[0]
      }
    ]
    setMessages(mockMessages)

    setStats({
      totalUsers: mockUsers.length,
      onlineUsers: mockUsers.filter(u => u.isOnline).length,
      totalMessages: mockMessages.length,
      messagesToday: mockMessages.filter(m => 
        new Date(m.createdAt).toDateString() === new Date().toDateString()
      ).length
    })
  }, [])

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Shield className="w-8 h-8 text-purple-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  GLXD Shop Admin
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Bảng điều khiển quản trị
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="outline" className="flex items-center space-x-2">
              <Activity className="w-4 h-4" />
              <span>System Online</span>
            </Badge>
            <Button variant="outline" size="sm" asChild>
              <Link href="/">
                <LogOut className="w-4 h-4 mr-2" />
                Đăng xuất
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tổng người dùng</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
              <p className="text-xs text-muted-foreground">
                {stats.onlineUsers} đang online
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tin nhắn hôm nay</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.messagesToday}</div>
              <p className="text-xs text-muted-foreground">
                Tổng {stats.totalMessages} tin nhắn
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Người dùng online</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.onlineUsers}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((stats.onlineUsers / stats.totalUsers) * 100)}% tổng users
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tỷ lệ hoạt động</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.totalMessages > 0 ? Math.round(stats.messagesToday / stats.totalUsers * 10) / 10 : 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Tin nhắn/người dùng hôm nay
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="users">Quản lý người dùng</TabsTrigger>
            <TabsTrigger value="messages">Giám sát tin nhắn</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Danh sách người dùng</CardTitle>
                <CardDescription>
                  Quản lý tất cả người dùng trong hệ thống
                </CardDescription>
                <div className="flex items-center space-x-2">
                  <Search className="w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Tìm kiếm người dùng..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {filteredUsers.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="relative">
                            <Avatar>
                              <AvatarFallback>
                                {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div
                              className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white dark:border-gray-800 ${
                                user.isOnline ? 'bg-green-500' : 'bg-gray-400'
                              }`}
                            />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h3 className="font-medium">{user.name}</h3>
                              <Badge variant={user.role === 'ADMIN' ? 'destructive' : 'secondary'}>
                                {user.role}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center space-x-1">
                              <Mail className="w-3 h-3" />
                              <span>{user.email}</span>
                            </p>
                            <p className="text-xs text-gray-400 dark:text-gray-500 flex items-center space-x-1">
                              <Calendar className="w-3 h-3" />
                              <span>Tham gia: {formatDate(user.createdAt)}</span>
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4 mr-2" />
                            Xem
                          </Button>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Xóa
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Giám sát tin nhắn</CardTitle>
                <CardDescription>
                  Xem tất cả tin nhắn trong hệ thống
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div key={message.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <Avatar className="w-6 h-6">
                              <AvatarFallback className="text-xs">
                                {message.sender.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span className="font-medium text-sm">{message.sender.name}</span>
                            <span className="text-gray-400">→</span>
                            <Avatar className="w-6 h-6">
                              <AvatarFallback className="text-xs">
                                {message.receiver.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span className="font-medium text-sm">{message.receiver.name}</span>
                          </div>
                          <span className="text-xs text-gray-500">
                            {formatDate(message.createdAt)} {formatTime(message.createdAt)}
                          </span>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                          <p className="text-sm">{message.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}