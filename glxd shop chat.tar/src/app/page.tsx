'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { MessageSquare, Users, Shield, Zap } from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="relative w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center">
              <MessageSquare className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">
            GLXD Shop Chat
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Nền tảng chat real-time hiện đại, kết nối khách hàng và quản lý hiệu quả
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Zap className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle className="text-lg">Real-time</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Chat tức thì với công nghệ Socket.IO tiên tiến
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle className="text-lg">Đa người dùng</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Hỗ trợ nhiều người dùng chat cùng lúc
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Shield className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle className="text-lg">Bảo mật</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Xác thực JWT và phân quyền rõ ràng
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <MessageSquare className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              </div>
              <CardTitle className="text-lg">Admin Panel</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Quản lý người dùng và tin nhắn dễ dàng
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 max-w-md mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Bắt đầu ngay hôm nay
            </h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Tham gia GLXD Shop Chat để trải nghiệm nền tảng chat tốt nhất
            </p>
            <div className="space-y-3">
              <Button asChild className="w-full" size="lg">
                <Link href="/login">
                  Đăng nhập
                </Link>
              </Button>
              <Button asChild variant="outline" className="w-full" size="lg">
                <Link href="/register">
                  Đăng ký tài khoản mới
                </Link>
              </Button>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <Button asChild variant="link" className="text-sm">
                <Link href="/admin">
                  Đăng nhập với tư cách Admin →
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-gray-500 dark:text-gray-400">
          <p>© 2024 GLXD Shop Chat. Powered by Next.js & Socket.IO</p>
        </div>
      </div>
    </div>
  )
}