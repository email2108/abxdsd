import { Server } from 'socket.io'
import { db } from './db'

interface User {
  id: string
  name: string
  email: string
  isOnline: boolean
}

interface Message {
  id: string
  content: string
  senderId: string
  receiverId: string
  createdAt: string
  sender?: User
}

export const setupSocket = (io: Server) => {
  const onlineUsers = new Map<string, User>()

  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id)

    // User joins
    socket.on('user:join', async (user: User) => {
      try {
        // Update user status in database
        await db.user.update({
          where: { id: user.id },
          data: { 
            isOnline: true,
            lastSeen: new Date()
          }
        })

        // Store user info
        onlineUsers.set(socket.id, user)
        
        // Broadcast user online status
        socket.broadcast.emit('user:status', {
          userId: user.id,
          isOnline: true
        })

        console.log(`User ${user.name} (${user.id}) joined`)
      } catch (error) {
        console.error('Error updating user status:', error)
      }
    })

    // Send message
    socket.on('message:send', async (data: Message) => {
      try {
        // Save message to database
        const savedMessage = await db.message.create({
          data: {
            senderId: data.senderId,
            receiverId: data.receiverId,
            content: data.content
          },
          include: {
            sender: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true
              }
            }
          }
        })

        // Find receiver's socket
        const receiverSocket = Array.from(onlineUsers.entries()).find(
          ([_, user]) => user.id === data.receiverId
        )?.[0]

        if (receiverSocket) {
          // Send to specific receiver
          io.to(receiverSocket).emit('message:receive', savedMessage)
        }

        // Send back to sender for confirmation
        socket.emit('message:receive', savedMessage)

        console.log(`Message from ${data.senderId} to ${data.receiverId}: ${data.content}`)
      } catch (error) {
        console.error('Error sending message:', error)
        socket.emit('error', { message: 'Failed to send message' })
      }
    })

    // Get messages between users
    socket.on('messages:get', async (data: { userId: string; receiverId: string }) => {
      try {
        const messages = await db.message.findMany({
          where: {
            OR: [
              {
                senderId: data.userId,
                receiverId: data.receiverId
              },
              {
                senderId: data.receiverId,
                receiverId: data.userId
              }
            ]
          },
          include: {
            sender: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true
              }
            }
          },
          orderBy: {
            createdAt: 'asc'
          }
        })

        socket.emit('messages:history', messages)
      } catch (error) {
        console.error('Error getting messages:', error)
        socket.emit('error', { message: 'Failed to get messages' })
      }
    })

    // Get online users
    socket.on('users:online', () => {
      const users = Array.from(onlineUsers.values())
      socket.emit('users:online', users)
    })

    // Handle disconnect
    socket.on('disconnect', async () => {
      try {
        const user = onlineUsers.get(socket.id)
        if (user) {
          // Update user status in database
          await db.user.update({
            where: { id: user.id },
            data: { 
              isOnline: false,
              lastSeen: new Date()
            }
          })

          // Remove from online users
          onlineUsers.delete(socket.id)

          // Broadcast user offline status
          socket.broadcast.emit('user:status', {
            userId: user.id,
            isOnline: false
          })

          console.log(`User ${user.name} (${user.id}) disconnected`)
        }
      } catch (error) {
        console.error('Error updating user status on disconnect:', error)
      }
    })

    // Send welcome message
    socket.emit('message:system', {
      text: 'Welcome to Real-time Chat!',
      timestamp: new Date().toISOString()
    })
  })
}