import { db } from './db'
import { hashPassword } from './auth'

async function seed() {
  try {
    console.log('Seeding database...')

    // Hash passwords for sample users
    const hashedPassword = await hashPassword('password123')

    // Create sample users
    const users = await Promise.all([
      db.user.create({
        data: {
          email: 'nguyena@example.com',
          name: 'Nguyễn Văn A',
          password: hashedPassword,
          isOnline: true,
          lastSeen: new Date()
        }
      }),
      db.user.create({
        data: {
          email: 'tranb@example.com',
          name: 'Trần Thị B',
          password: hashedPassword,
          isOnline: false,
          lastSeen: new Date(Date.now() - 3600000) // 1 hour ago
        }
      }),
      db.user.create({
        data: {
          email: 'lec@example.com',
          name: 'Lê Văn C',
          password: hashedPassword,
          isOnline: true,
          lastSeen: new Date()
        }
      }),
      db.user.create({
        data: {
          email: 'phamd@example.com',
          name: 'Phạm Thị D',
          password: hashedPassword,
          isOnline: false,
          lastSeen: new Date(Date.now() - 7200000) // 2 hours ago
        }
      })
    ])

    console.log('Created users:', users.length)

    // Create sample messages
    const messages = await Promise.all([
      db.message.create({
        data: {
          content: 'Xin chào! Bạn có khỏe không?',
          senderId: users[0].id,
          receiverId: users[2].id
        }
      }),
      db.message.create({
        data: {
          content: 'Mình khỏe, cảm ơn bạn!',
          senderId: users[2].id,
          receiverId: users[0].id
        }
      }),
      db.message.create({
        data: {
          content: 'Hôm nay bạn có dự định gì không?',
          senderId: users[0].id,
          receiverId: users[2].id
        }
      }),
      db.message.create({
        data: {
          content: 'Mình định đi uống cà phê, bạn có đi không?',
          senderId: users[2].id,
          receiverId: users[0].id
        }
      })
    ])

    console.log('Created messages:', messages.length)

    console.log('Database seeded successfully!')
    console.log('Demo accounts:')
    console.log('Email: nguyena@example.com, Password: password123')
    console.log('Email: lec@example.com, Password: password123')
  } catch (error) {
    console.error('Error seeding database:', error)
  }
}

seed()