import { readFileSync, existsSync } from 'fs'
import path from 'path'
import { exec } from 'child_process'

export interface SSLOptions {
  key: string
  cert: string
  ca?: string
}

export function getSSLOptions(): SSLOptions | null {
  const sslDir = path.join(process.cwd(), 'ssl')
  
  const certPath = path.join(sslDir, 'cert.pem')
  const keyPath = path.join(sslDir, 'privkey.pem')
  const chainPath = path.join(sslDir, 'chain.pem')
  
  if (!existsSync(certPath) || !existsSync(keyPath)) {
    console.warn('SSL certificate files not found. Running in HTTP mode.')
    return null
  }
  
  try {
    const sslOptions: SSLOptions = {
      key: readFileSync(keyPath, 'utf8'),
      cert: readFileSync(certPath, 'utf8'),
    }
    
    if (existsSync(chainPath)) {
      sslOptions.ca = readFileSync(chainPath, 'utf8')
    }
    
    return sslOptions
  } catch (error) {
    console.error('Error reading SSL certificate files:', error)
    return null
  }
}

export function isSSLConfigured(): boolean {
  return getSSLOptions() !== null
}

export function generateSelfSignedCert() {
  const sslDir = path.join(process.cwd(), 'ssl')
  
  const command = `openssl req -x509 -newkey rsa:4096 -keyout ${sslDir}/privkey.pem -out ${sslDir}/cert.pem -days 365 -nodes -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"`
  
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error('Error generating self-signed certificate:', error)
      return
    }
    
    if (stderr) {
      console.error('OpenSSL stderr:', stderr)
    }
    
    console.log('Self-signed certificate generated successfully')
    console.log('Certificate files created in:', sslDir)
  })
}