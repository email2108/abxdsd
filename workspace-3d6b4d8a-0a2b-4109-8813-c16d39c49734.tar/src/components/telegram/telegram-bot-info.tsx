'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { MessageCircle, ExternalLink, Copy, CheckCircle, Shield } from 'lucide-react'
import { useState } from 'react'

export function TelegramBotInfo() {
  const [copied, setCopied] = useState(false)
  const botUsername = "glxdshop_bot"
  const botLink = `https://t.me/${botUsername}`

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-blue-500" />
          Telegram Bot GLXĐ Shop
        </CardTitle>
        <CardDescription className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-green-500" />
          Hệ thống gửi OTP và thông báo qua Telegram Bot (Bảo mật)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Bot Info */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Bot Username:</span>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">@{botUsername}</Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(botUsername)}
              >
                {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Trạng thái bảo mật:</span>
            <Badge variant="default" className="bg-green-500">
              <Shield className="h-3 w-3 mr-1" />
              Token đã được ẩn
            </Badge>
          </div>
        </div>

        {/* Bot Link */}
        <div className="space-y-2">
          <span className="text-sm font-medium">Truy cập Bot:</span>
          <Button asChild className="w-full">
            <a
              href={botLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2"
            >
              <MessageCircle className="h-4 w-4" />
              Mở @{botUsername} trên Telegram
              <ExternalLink className="h-4 w-4" />
            </a>
          </Button>
        </div>

        {/* Features */}
        <div className="space-y-3">
          <span className="text-sm font-medium">Tính năng:</span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <Badge variant="outline" className="justify-center">
              📧 Gửi OTP
            </Badge>
            <Badge variant="outline" className="justify-center">
              🔔 Thông báo
            </Badge>
            <Badge variant="outline" className="justify-center">
              👋 Welcome message
            </Badge>
            <Badge variant="outline" className="justify-center">
              📊 Admin notifications
            </Badge>
          </div>
        </div>

        {/* Instructions */}
        <div className="space-y-2">
          <span className="text-sm font-medium">Hướng dẫn sử dụng:</span>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>1. Click vào link bên trên để mở bot</p>
            <p>2. Nhấn /start để bắt đầu</p>
            <p>3. Lấy Chat ID bằng cách chat với @userinfobot</p>
            <p>4. Nhập Chat ID vào form đăng ký để nhận OTP qua Telegram</p>
          </div>
        </div>

        {/* Security Note */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <div className="flex items-center gap-2 text-green-700">
            <Shield className="h-4 w-4" />
            <span className="text-sm font-medium">Bảo mật được đảm bảo</span>
          </div>
          <p className="text-xs text-green-600 mt-1">
            Token bot được lưu trữ an toàn trong biến môi trường và không hiển thị công khai.
          </p>
        </div>

        {/* Status */}
        <div className="flex items-center justify-center">
          <Badge variant="default" className="bg-green-500">
            ✅ Bot đang hoạt động
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}