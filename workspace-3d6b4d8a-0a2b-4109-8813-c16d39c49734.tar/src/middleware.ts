import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { getTokenFromHeaders, verifyToken } from './lib/auth'

export function middleware(request: NextRequest) {
  // Get token from headers
  const token = getTokenFromHeaders(request.headers)
  
  // Protected routes that require authentication
  const protectedPaths = ['/chat', '/profile', '/settings']
  const isProtectedPath = protectedPaths.some(path => 
    request.nextUrl.pathname.startsWith(path)
  )

  // If accessing protected route without token, redirect to login
  if (isProtectedPath && !token) {
    return NextResponse.redirect(new URL('/auth/login', request.url))
  }

  // If accessing protected route with invalid token, redirect to login
  if (isProtectedPath && token) {
    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.redirect(new URL('/auth/login', request.url))
    }
  }

  // If accessing auth pages while logged in, redirect to chat
  const authPaths = ['/auth/login', '/auth/register']
  const isAuthPath = authPaths.some(path => 
    request.nextUrl.pathname.startsWith(path)
  )

  if (isAuthPath && token) {
    const payload = verifyToken(token)
    if (payload) {
      return NextResponse.redirect(new URL('/chat', request.url))
    }
  }

  // Check if the request is secure
  if (process.env.NODE_ENV === 'production' && !request.secure) {
    // Get the hostname
    const host = request.headers.get('host')
    
    // Construct HTTPS URL
    const httpsUrl = `https://${host}${request.nextUrl.pathname}${request.nextUrl.search}`
    
    // Redirect to HTTPS
    return NextResponse.redirect(httpsUrl)
  }
  
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}