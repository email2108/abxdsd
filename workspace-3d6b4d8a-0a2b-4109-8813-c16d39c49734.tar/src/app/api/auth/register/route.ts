import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, generateToken } from '@/lib/auth'

export async function POST(request: Request) {
  try {
    const { name, email, phone, telegramChatId, password } = await request.json()

    // Validate required fields
    if (!name || !email || !password) {
      return NextResponse.json(
        { success: false, message: 'Vui lòng điền đầy đủ thông tin bắt buộc' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findFirst({
      where: {
        OR: [
          { email },
          ...(phone ? [{ phone }] : []),
          ...(telegramChatId ? [{ telegramChatId }] : [])
        ]
      }
    })

    if (existingUser) {
      return NextResponse.json(
        { success: false, message: 'Email hoặc thông tin liên hệ đã được sử dụng' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await hashPassword(password)

    // Create new user
    const newUser = await db.user.create({
      data: {
        name,
        email,
        phone,
        telegramChatId,
        password: hashedPassword,
        isOnline: false
      },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        telegramChatId: true,
        avatar: true,
        isOnline: true,
        createdAt: true
      }
    })

    // Generate token
    const token = generateToken({
      userId: newUser.id,
      email: newUser.email,
      name: newUser.name
    })

    return NextResponse.json({
      success: true,
      message: 'Đăng ký thành công',
      user: newUser,
      token
    })

  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { success: false, message: 'Đăng ký thất bại, vui lòng thử lại' },
      { status: 500 }
    )
  }
}