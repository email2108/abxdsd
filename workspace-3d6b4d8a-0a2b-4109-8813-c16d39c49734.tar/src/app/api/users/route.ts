import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getTokenFromHeaders, verifyToken } from '@/lib/auth'

export async function GET(request: Request) {
  try {
    // Get token from headers
    const token = getTokenFromHeaders(request.headers)
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      )
    }

    // Verify token
    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json(
        { success: false, message: 'Invalid token' },
        { status: 401 }
      )
    }

    // Get all users except current user
    const users = await db.user.findMany({
      where: {
        id: {
          not: payload.userId
        }
      },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        telegramChatId: true,
        avatar: true,
        isOnline: true,
        lastSeen: true,
        createdAt: true
      },
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json({ success: true, users })
  } catch (error) {
    console.error('Get users error:', error)
    return NextResponse.json(
      { success: false, message: 'Failed to get users' },
      { status: 500 }
    )
  }
}