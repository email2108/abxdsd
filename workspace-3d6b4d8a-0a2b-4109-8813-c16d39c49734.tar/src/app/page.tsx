import { TelegramBotInfo } from '@/components/telegram/telegram-bot-info'
import { Button } from '@/components/ui/button'
import { MessageSquare, Users } from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-8 p-4">
      <div className="relative w-24 h-24 md:w-32 md:h-32">
        <img
          src="/logo.svg"
          alt="Z.ai Logo"
          className="w-full h-full object-contain"
        />
      </div>
      
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900">
          Chào mừng đến với Hệ Thống Chat
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl">
          Trải nghiệm chat real-time với nhiều người dùng. Kết nối và trò chuyện ngay!
        </p>
      </div>

      <div className="flex gap-4">
        <Link href="/chat">
          <Button size="lg" className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Bắt đầu chat
          </Button>
        </Link>
        <Link href="/auth/login">
          <Button variant="outline" size="lg" className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Đăng nhập
          </Button>
        </Link>
      </div>
      
      <div className="w-full max-w-4xl">
        <TelegramBotInfo />
      </div>
    </div>
  )
}