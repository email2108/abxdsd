'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { MessageSquare, Send, Users, Online, LogOut } from 'lucide-react'
import { io, Socket } from 'socket.io-client'

interface User {
  id: string
  name: string
  email: string
  isOnline: boolean
  avatar?: string
}

interface Message {
  id: string
  content: string
  senderId: string
  receiverId: string
  createdAt: string
  sender?: User
}

export default function ChatPage() {
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [newMessage, setNewMessage] = useState('')
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [socket, setSocket] = useState<Socket | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')

    if (!token || !userData) {
      router.push('/auth/login')
      return
    }

    try {
      const user = JSON.parse(userData)
      setCurrentUser(user)
    } catch (error) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      router.push('/auth/login')
      return
    }

    setIsLoading(false)
  }, [router])

  useEffect(() => {
    if (!currentUser) return

    // Initialize socket connection
    const newSocket = io('http://localhost:3000')
    setSocket(newSocket)

    // Fetch users and messages
    fetchUsers()
    fetchMessages()

    // Socket event listeners
    newSocket.on('connect', () => {
      console.log('Connected to server')
      newSocket.emit('user:join', currentUser)
    })

    newSocket.on('message:receive', (message: Message) => {
      setMessages(prev => [...prev, message])
    })

    newSocket.on('user:status', (data: { userId: string; isOnline: boolean }) => {
      setUsers(prev => prev.map(user => 
        user.id === data.userId ? { ...user, isOnline: data.isOnline } : user
      ))
    })

    newSocket.on('users:online', (onlineUsers: User[]) => {
      setUsers(prev => prev.map(user => {
        const onlineUser = onlineUsers.find(u => u.id === user.id)
        return onlineUser ? { ...user, isOnline: true } : user
      }))
    })

    return () => {
      newSocket.disconnect()
    }
  }, [currentUser])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users')
      if (response.ok) {
        const usersData = await response.json()
        setUsers(usersData)
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    }
  }

  const fetchMessages = async () => {
    if (!currentUser) return

    try {
      const response = await fetch(`/api/messages?userId=${currentUser.id}`)
      if (response.ok) {
        const messagesData = await response.json()
        setMessages(messagesData)
      }
    } catch (error) {
      console.error('Error fetching messages:', error)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const sendMessage = () => {
    if (!newMessage.trim() || !selectedUser || !socket || !currentUser) return

    const message: Message = {
      id: Date.now().toString(),
      content: newMessage,
      senderId: currentUser.id,
      receiverId: selectedUser.id,
      createdAt: new Date().toISOString(),
      sender: currentUser
    }

    // Add to local messages
    setMessages(prev => [...prev, message])
    
    // Send via socket
    socket.emit('message:send', message)
    
    // Clear input
    setNewMessage('')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/')
  }

  const filteredMessages = selectedUser && currentUser
    ? messages.filter(msg => 
        (msg.senderId === currentUser.id && msg.receiverId === selectedUser.id) ||
        (msg.senderId === selectedUser.id && msg.receiverId === currentUser.id)
      )
    : []

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Đang tải...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto h-[calc(100vh-2rem)]">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <MessageSquare className="h-8 w-8 text-blue-500" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Hệ Thống Chat</h1>
              <p className="text-sm text-gray-600">
                Chào mừng, {currentUser?.name}!
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Đăng xuất
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-full">
          {/* Users List */}
          <Card className="lg:col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="h-5 w-5" />
                Danh sách người dùng ({users.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-12rem)]">
                <div className="space-y-2 p-4">
                  {users.map(user => (
                    user.id !== currentUser?.id && (
                      <div
                        key={user.id}
                        className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors hover:bg-gray-100 ${
                          selectedUser?.id === user.id ? 'bg-blue-50 border border-blue-200' : ''
                        }`}
                        onClick={() => setSelectedUser(user)}
                      >
                        <div className="relative">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          {user.isOnline && (
                            <div className="absolute -bottom-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-white" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm truncate">
                              {user.name}
                            </span>
                            {user.isOnline && (
                              <Badge variant="secondary" className="text-xs">
                                <Online className="h-3 w-3 mr-1" />
                                Online
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">
                            {user.email}
                          </p>
                        </div>
                      </div>
                    )
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Chat Area */}
          <Card className="lg:col-span-3 flex flex-col">
            {selectedUser ? (
              <>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>
                        {selectedUser.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg">{selectedUser.name}</CardTitle>
                      <div className="flex items-center gap-2">
                        {selectedUser.isOnline ? (
                          <Badge variant="secondary" className="text-xs">
                            <Online className="h-3 w-3 mr-1" />
                            Online
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">Offline</span>
                        )}
                        <span className="text-xs text-muted-foreground">
                          {selectedUser.email}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="flex-1 p-0">
                  <ScrollArea className="h-[calc(100vh-20rem)] p-4">
                    <div className="space-y-4">
                      {filteredMessages.map(message => (
                        <div
                          key={message.id}
                          className={`flex ${
                            message.senderId === currentUser?.id ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              message.senderId === currentUser?.id
                                ? 'bg-blue-500 text-white'
                                : 'bg-gray-200 text-gray-900'
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p
                              className={`text-xs mt-1 ${
                                message.senderId === currentUser?.id
                                  ? 'text-blue-100'
                                  : 'text-gray-500'
                              }`}
                            >
                              {new Date(message.createdAt).toLocaleTimeString('vi-VN', {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>
                </CardContent>
                
                <Separator />
                
                <CardContent className="p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Nhập tin nhắn..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="flex-1"
                      disabled={!selectedUser?.isOnline}
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={!newMessage.trim() || !selectedUser?.isOnline}
                      size="icon"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  {!selectedUser?.isOnline && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Người dùng này hiện đang offline. Tin nhắn sẽ được gửi khi họ online.
                    </p>
                  )}
                </CardContent>
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <MessageSquare className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Chọn người dùng để chat
                  </h3>
                  <p className="text-gray-500">
                    Chọn một người dùng từ danh sách bên trái để bắt đầu trò chuyện
                  </p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}"