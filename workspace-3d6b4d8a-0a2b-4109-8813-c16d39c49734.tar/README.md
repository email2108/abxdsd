# 🎉 Hệ Thống L2M Với Telegram OTP và Trang Admin Riêng

Một hệ thống hoàn chỉnh cho phép xác thực người dùng qua nhiều kênh OTP (Email, SMS, Telegram) với trang quản trị riêng biệt.

## ✨ Tính Năng Chính

### 🔐 Xác Thực Đa Kênh
- **3 Phương Thức OTP**: Email, SMS, và Telegram
- **Telegram Bot Integration**: Gửi OTP qua @glxdshop_bot
- **Tự Động Hết Hạn**: OTP tự động hết hạn sau 5 phút
- **Rate Limiting**: Ngăn gửi OTP liên tục
- **Log Tracking**: Ghi lại tất cả lần gửi OTP

### 👥 Phân Tách Admin và User
- **Trang User**: http://localhost:3000 - Dành cho người dùng thông thường
- **Trang Admin**: http://localhost:3000/admin - Dành cho quản trị viên
- **Phân Quyện Rõ Ràng**: User không thể truy cập admin và ngược lại
- **Session Riêng**: Admin và user có session riêng biệt

### 📊 Admin Panel Chuyên Dụng
- **Thống Kê Tổng Quan**:
  - Tổng số users
  - Referrals đang chờ duyệt
  - User đăng ký hôm nay
  - Tổng thu nhập hệ thống
- **Quản Lý Hệ Thống**: Phân tích chi tiết, quản lý referrals, theo dõi thu nhập
- **Công Cụ Tạo Link**: Tạo và quản lý link giới thiệu

### 🤖 Telegram Bot Features
- **Bot Username**: @glxdshop_bot
- **Bot Token**: 7856893063:AAFhYTUkhnxuhY18tA9AnOFvmQiiu2Jx6DY
- **Welcome Messages**: Tin nhắn chào mừng tự động khi đăng ký
- **Admin Notifications**: Gửi thông báo đến admin qua Telegram
- **HTML Formatting**: Hỗ trợ định dạng HTML cho messages

## 🚀 Quick Start

### Cài Đặt
```bash
# Clone dự án
git clone <repository-url>
cd l2m-telegram-system

# Cài đặt dependencies
npm install

# Cấu hình environment variables
cp .env.example .env.local

# Khởi tạo database
npm run db:push

# Bắt đầu development server
npm run dev
```

### Cấu Hình Environment
```bash
# .env.local
DATABASE_URL="file:/home/z/my-project/db/custom.db"

# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=7856893063:AAFhYTUkhnxuhY18tA9AnOFvmQiiu2Jx6DY
TELEGRAM_ADMIN_CHAT_ID=your_admin_chat_id_here

# Email Configuration
EMAIL_HOST=smtp.example.com
EMAIL_PORT=587
EMAIL_USER=your_email@example.com
EMAIL_PASS=your_email_password

# SMS Configuration
SMS_API_KEY=your_sms_api_key
```

## 🎯 Luồng Hoạt Động

### User Đăng Ký/Đăng Nhập
1. **Truy cập**: http://localhost:3000
2. **Chọn phương thức**: Email, SMS, hoặc Telegram
3. **Nhập thông tin**: Tùy theo phương thức đã chọn
4. **Nhận OTP**: Qua kênh đã chọn (Telegram bot sẽ gửi message)
5. **Xác thực**: Nhập OTP để hoàn tất đăng ký/đăng nhập

### Admin Đăng Nhập
1. **Truy cập**: http://localhost:3000/admin
2. **Đăng nhập**: Sử dụng tài khoản admin
3. **Nhận OTP**: Qua kênh đã cấu hình
4. **Truy cập**: Admin panel với full features

## 📱 Giao Diện

### Trang Chủ (User)
- **2 Tabs**: Đăng ký & Đăng nhập
- **3 Phương Thức OTP**: Email, SMS, Telegram
- **Dashboard**: Giới thiệu cơ bản cho user đã đăng nhập
- **Hướng Dẫn**: Hướng dẫn lấy Chat ID từ Telegram

### Trang Admin
- **Header Riêng**: Admin panel header với branding riêng
- **Form Login**: Form đăng nhập admin riêng
- **Dashboard**: Full features với phân tích chi tiết
- **Thống Kê**: Cards hiển thị số liệu hệ thống

## 🔧 Technology Stack

### Core Framework
- **⚡ Next.js 15** - React framework với App Router
- **📘 TypeScript 5** - Type-safe JavaScript
- **🎨 Tailwind CSS 4** - Utility-first CSS framework
- **🧩 shadcn/ui** - High-quality components

### Backend & Database
- **🗄️ Prisma** - Next-generation ORM
- **🔐 NextAuth.js** - Authentication solution
- **🌐 Socket.io** - Real-time communication
- **🤖 Z-AI Web Dev SDK** - AI integration

### UI & UX
- **🎯 Lucide React** - Icon library
- **🌈 Framer Motion** - Animation library
- **📊 Recharts** - Chart library
- **🎣 React Hook Form** - Form handling

## 🛡️ Security

### OTP Security
- **Expiry**: 5 phút tự động hết hạn
- **Rate Limiting**: Ngăn gửi OTP liên tục
- **Log Tracking**: Ghi lại tất cả lần gửi OTP
- **Encryption**: Mã hóa OTP trong database

### Authentication Security
- **Session Management**: Phân biệt user/admin sessions
- **Route Protection**: Middleware kiểm tra permissions
- **Input Validation**: Validate tất cả input data
- **Error Handling**: Không leak sensitive information

## 📁 Project Structure

```
src/
├── app/
│   ├── (auth)/
│   │   ├── login/page.tsx
│   │   └── register/page.tsx
│   ├── admin/
│   │   ├── login/page.tsx
│   │   └── dashboard/page.tsx
│   ├── dashboard/
│   │   └── page.tsx
│   └── api/
│       ├── auth/
│       │   ├── login/route.ts
│       │   ├── register/route.ts
│       │   └── verify-otp/route.ts
│       ├── admin/
│       │   └── stats/route.ts
│       └── telegram/
│           └── send-otp/route.ts
├── components/
│   ├── auth/
│   │   ├── LoginForm.tsx
│   │   ├── RegisterForm.tsx
│   │   └── OTPVerification.tsx
│   ├── admin/
│   │   ├── AdminHeader.tsx
│   │   └── StatsCard.tsx
│   └── telegram/
│       └── TelegramBotInfo.tsx
└── lib/
    ├── auth.ts
    ├── telegram.ts
    ├── email.ts
    ├── sms.ts
    └── utils.ts
```

## 🔍 Database Schema

```prisma
model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  phone     String?
  telegramChatId String?
  role      Role     @default(USER)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  otps      OTP[]
  referrals Referral[]
  posts     Post[]
}

model OTP {
  id        String   @id @default(cuid())
  code      String
  type      OTPType
  sentTo    String
  userId    String
  expiresAt DateTime
  used      Boolean  @default(false)
  createdAt DateTime @default(now())
  
  user      User     @relation(fields: [userId], references: [id])
}

model Referral {
  id        String   @id @default(cuid())
  code      String   @unique
  userId    String
  status    ReferralStatus @default(PENDING)
  earnings  Float    @default(0)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  user      User     @relation(fields: [userId], references: [id])
}

enum Role {
  USER
  ADMIN
}

enum OTPType {
  EMAIL
  SMS
  TELEGRAM
}

enum ReferralStatus {
  PENDING
  APPROVED
  REJECTED
}
```

## 🎯 Development Commands

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint

# Database
npm run db:push      # Push schema to database
npm run db:generate  # Generate Prisma client
npm run db:migrate   # Run migrations
npm run db:reset     # Reset database
```

## 🌟 Features Showcase

### Telegram Integration
- **Bot Link**: https://t.me/glxdshop_bot
- **Features**:
  - 📧 Gửi OTP tự động
  - 🔔 Thông báo hệ thống
  - 👋 Welcome messages
  - 📊 Admin notifications

### User Experience
- **Responsive Design**: Mobile-first approach
- **Dark Mode**: Built-in theme switching
- **Loading States**: Skeleton loaders và spinners
- **Error Handling**: Clear error messages
- **Accessibility**: ARIA support và keyboard navigation

### Admin Features
- **Dashboard**: Thống kê real-time
- **User Management**: Quản lý users và permissions
- **Referral System**: Tạo và quản lý referrals
- **Analytics**: Charts và detailed reports
- **Notifications**: Real-time notifications

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🚀 Production Deployment

### Environment Variables
```bash
# Production
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://yourdomain.com
DATABASE_URL=your_production_database_url
TELEGRAM_BOT_TOKEN=7856893063:AAFhYTUkhnxuhY18tA9AnOFvmQiiu2Jx6DY
TELEGRAM_ADMIN_CHAT_ID=your_admin_chat_id
```

### Deployment Steps
1. **Build**: `npm run build`
2. **Setup Database**: Configure production database
3. **Environment**: Set production environment variables
4. **Deploy**: Deploy to Vercel/Netlify/AWS
5. **Test**: Test all features including Telegram integration

---

**Status**: Ready for development  
**Priority**: High  
**Estimated Timeline**: 2-3 weeks for complete implementation

Built with ❤️ for the L2M system. Supercharged by Z.ai 🚀
