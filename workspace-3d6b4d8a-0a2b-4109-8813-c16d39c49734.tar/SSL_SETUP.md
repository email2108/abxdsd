# 🔒 SSL Certificate Setup Guide

## 📋 SSL Certificate Information

**Certificate**: `cert_HpIgSDGIvxvYI2dl9uArerAk`  
**Status**: Ready for configuration  
**Type**: SSL Certificate  

## 🚀 SSL Configuration Steps

### 1. SSL Certificate Files

Create the necessary SSL certificate files in your project:

```bash
# Create SSL directory
mkdir -p /home/z/my-project/ssl

# Create certificate files
touch /home/z/my-project/ssl/cert.pem
touch /home/z/my-project/ssl/privkey.pem
touch /home/z/my-project/ssl/chain.pem
touch /home/z/my-project/ssl/fullchain.pem
```

### 2. Certificate File Contents

Add your SSL certificate details to the respective files:

**File: `/home/z/my-project/ssl/cert.pem`**
```pem
-----BEGIN CERTIFICATE-----
# Your certificate content here
# Replace with your actual cert_HpIgSDGIvxvYI2dl9uArerAk certificate
-----END CERTIFICATE-----
```

**File: `/home/z/my-project/ssl/privkey.pem`**
```pem
-----BEGIN PRIVATE KEY-----
# Your private key content here
-----END PRIVATE KEY-----
```

**File: `/home/z/my-project/ssl/chain.pem`**
```pem
-----BEGIN CERTIFICATE-----
# Your chain certificate content here
-----END CERTIFICATE-----
```

**File: `/home/z/my-project/ssl/fullchain.pem`**
```pem
-----BEGIN CERTIFICATE-----
# Your full chain certificate content here
-----END CERTIFICATE-----
```

### 3. Update Next.js Configuration

Update your Next.js configuration to support HTTPS:

**File: `/home/z/my-project/next.config.ts`**
```typescript
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Existing configuration...
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload',
          },
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig
```

### 4. Update Server Configuration

Update your server configuration to use SSL:

**File: `/home/z/my-project/server.ts`**
```typescript
import { createServer } from 'https'
import { readFileSync } from 'fs'
import { parse } from 'url'
import next from 'next'

const dev = process.env.NODE_ENV !== 'production'
const hostname = 'localhost'
const port = 3000

// SSL Configuration
const sslOptions = {
  key: readFileSync('./ssl/privkey.pem'),
  cert: readFileSync('./ssl/cert.pem'),
  ca: readFileSync('./ssl/chain.pem'),
}

const app = next({ dev, hostname, port })
const handler = app.getRequestHandler()

app.prepare().then(() => {
  createServer(sslOptions, async (req, res) => {
    try {
      const parsedUrl = parse(req.url!, true)
      await handler(req, res, parsedUrl)
    } catch (err) {
      console.error('Error occurred handling', req.url, err)
      res.statusCode = 500
      res.end('internal server error')
    }
  })
    .once('error', (err) => {
      console.error(err)
      process.exit(1)
    })
    .listen(port, () => {
      console.log(`> Ready on https://${hostname}:${port}`)
    })
})
```

### 5. Environment Variables

Update your environment file to include SSL configuration:

**File: `/home/z/my-project/.env`**
```bash
# Database
DATABASE_URL=file:/home/z/my-project/db/custom.db

# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=7856893063:AAFhYTUkhnxuhY18tA9AnOFvmQiiu2Jx6DY
TELEGRAM_ADMIN_CHAT_ID=your_admin_chat_id_here

# SSL Configuration
SSL_CERT_PATH=./ssl/cert.pem
SSL_KEY_PATH=./ssl/privkey.pem
SSL_CHAIN_PATH=./ssl/chain.pem
SSL_FULLCHAIN_PATH=./ssl/fullchain.pem

# Application URLs
NEXT_PUBLIC_APP_URL=https://localhost:3000
NEXT_PUBLIC_API_URL=https://localhost:3000/api
```

### 6. Create SSL Helper Utility

Create a utility to handle SSL configuration:

**File: `/home/z/my-project/src/lib/ssl.ts`**
```typescript
import { readFileSync, existsSync } from 'fs'
import path from 'path'

export interface SSLOptions {
  key: string
  cert: string
  ca?: string
}

export function getSSLOptions(): SSLOptions | null {
  const sslDir = path.join(process.cwd(), 'ssl')
  
  const certPath = path.join(sslDir, 'cert.pem')
  const keyPath = path.join(sslDir, 'privkey.pem')
  const chainPath = path.join(sslDir, 'chain.pem')
  
  if (!existsSync(certPath) || !existsSync(keyPath)) {
    console.warn('SSL certificate files not found. Running in HTTP mode.')
    return null
  }
  
  try {
    const sslOptions: SSLOptions = {
      key: readFileSync(keyPath, 'utf8'),
      cert: readFileSync(certPath, 'utf8'),
    }
    
    if (existsSync(chainPath)) {
      sslOptions.ca = readFileSync(chainPath, 'utf8')
    }
    
    return sslOptions
  } catch (error) {
    console.error('Error reading SSL certificate files:', error)
    return null
  }
}

export function isSSLConfigured(): boolean {
  return getSSLOptions() !== null
}
```

### 7. Update Package.json Scripts

Add SSL-specific scripts to your package.json:

**File: `/home/z/my-project/package.json`**
```json
{
  "scripts": {
    "dev": "nodemon --exec \"npx tsx server.ts\" --watch server.ts --watch src --ext ts,tsx,js,jsx 2>&1 | tee dev.log",
    "dev:ssl": "nodemon --exec \"NODE_ENV=production npx tsx server.ts\" --watch server.ts --watch src --ext ts,tsx,js,jsx 2>&1 | tee dev-ssl.log",
    "build": "next build",
    "start": "NODE_ENV=production tsx server.ts 2>&1 | tee server.log",
    "start:ssl": "NODE_ENV=production SSL_ENABLED=true tsx server.ts 2>&1 | tee server-ssl.log",
    "lint": "next lint",
    "db:push": "prisma db push",
    "db:generate": "prisma generate",
    "db:migrate": "prisma migrate dev",
    "db:reset": "prisma migrate reset",
    "ssl:generate": "openssl req -x509 -newkey rsa:4096 -keyout ssl/privkey.pem -out ssl/cert.pem -days 365 -nodes"
  }
}
```

### 8. Create SSL Middleware

Create middleware to enforce HTTPS in production:

**File: `/home/z/my-project/src/middleware.ts`**
```typescript
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  // Check if the request is secure
  if (process.env.NODE_ENV === 'production' && !request.secure) {
    // Redirect to HTTPS
    const httpsUrl = `https://${request.nextUrl.hostname}${request.nextUrl.pathname}${request.nextUrl.search}`
    return NextResponse.redirect(httpsUrl)
  }
  
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
```

### 9. Update Development Scripts

Create a development script that can handle both HTTP and HTTPS:

**File: `/home/z/my-project/dev-ssl.js`**
```javascript
const { createServer } = require('https')
const { readFileSync } = require('fs')
const { parse } = require('url')
const next = require('next')

const dev = process.env.NODE_ENV !== 'production'
const hostname = 'localhost'
const port = 3000

// Check if SSL is enabled
const useSSL = process.env.SSL_ENABLED === 'true' || process.env.NODE_ENV === 'production'

let server

if (useSSL) {
  try {
    const sslOptions = {
      key: readFileSync('./ssl/privkey.pem'),
      cert: readFileSync('./ssl/cert.pem'),
      ca: readFileSync('./ssl/chain.pem'),
    }
    
    const app = next({ dev, hostname, port })
    const handler = app.getRequestHandler()
    
    app.prepare().then(() => {
      server = createServer(sslOptions, async (req, res) => {
        try {
          const parsedUrl = parse(req.url, true)
          await handler(req, res, parsedUrl)
        } catch (err) {
          console.error('Error occurred handling', req.url, err)
          res.statusCode = 500
          res.end('internal server error')
        }
      })
        .once('error', (err) => {
          console.error(err)
          process.exit(1)
        })
        .listen(port, () => {
          console.log(`> Ready on https://${hostname}:${port}`)
        })
    })
  } catch (error) {
    console.error('SSL configuration error:', error)
    console.log('Falling back to HTTP...')
    // Fallback to HTTP
    require('./server.js')
  }
} else {
  // Use HTTP
  require('./server.js')
}
```

## 🔧 SSL Certificate Installation

### For Production (Domain-based Certificate)

1. **Obtain SSL Certificate**:
   ```bash
   # Using Let's Encrypt
   sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com
   ```

2. **Copy Certificate Files**:
   ```bash
   sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem /home/z/my-project/ssl/
   sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem /home/z/my-project/ssl/
   sudo cp /etc/letsencrypt/live/yourdomain.com/chain.pem /home/z/my-project/ssl/
   ```

3. **Set Permissions**:
   ```bash
   sudo chmod 600 /home/z/my-project/ssl/*.pem
   sudo chown $USER:$USER /home/z/my-project/ssl/*.pem
   ```

### For Development (Self-signed Certificate)

1. **Generate Self-signed Certificate**:
   ```bash
   npm run ssl:generate
   ```

2. **Trust the Certificate** (macOS):
   ```bash
   sudo security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain ssl/cert.pem
   ```

3. **Trust the Certificate** (Linux):
   ```bash
   sudo cp ssl/cert.pem /usr/local/share/ca-certificates/
   sudo update-ca-certificates
   ```

## 🚀 Testing SSL Configuration

### Test HTTPS Server
```bash
# Start with SSL
npm run dev:ssl

# Or for production
npm run start:ssl
```

### Test SSL Certificate
```bash
# Test SSL connection
openssl s_client -connect localhost:3000 -showcerts

# Test SSL certificate
openssl x509 -in ssl/cert.pem -text -noout
```

### Test HTTPS Endpoints
```bash
# Test API endpoint
curl -k https://localhost:3000/api/health

# Test with SSL verification
curl -v https://localhost:3000
```

## 🛡️ SSL Security Headers

Add these security headers to your Next.js configuration:

**File: `/home/z/my-project/next.config.ts`**
```typescript
/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload',
          },
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
          {
            key: 'Content-Security-Policy',
            value: "default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' https: wss:;",
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig
```

## 📋 SSL Configuration Checklist

- [ ] Create SSL directory structure
- [ ] Add certificate files (cert.pem, privkey.pem, chain.pem, fullchain.pem)
- [ ] Update Next.js configuration
- [ ] Update server configuration
- [ ] Add SSL environment variables
- [ ] Create SSL utility functions
- [ ] Update package.json scripts
- [ ] Create HTTPS middleware
- [ ] Test SSL configuration
- [ ] Set up production SSL certificates
- [ ] Configure security headers

## 🔍 Troubleshooting

### Common Issues

1. **SSL Certificate Not Found**:
   - Check if certificate files exist in the ssl directory
   - Verify file permissions
   - Ensure paths are correct

2. **Certificate Validation Error**:
   - Verify certificate chain is complete
   - Check certificate expiration date
   - Ensure domain matches certificate

3. **HTTPS Redirect Loop**:
   - Check middleware configuration
   - Verify environment variables
   - Test without HTTPS redirect

4. **Mixed Content Errors**:
   - Ensure all resources use HTTPS
   - Update hardcoded HTTP URLs
   - Check third-party resources

### Debug Commands

```bash
# Check SSL certificate details
openssl x509 -in ssl/cert.pem -text -noout

# Test SSL connection
openssl s_client -connect localhost:3000

# Check certificate chain
openssl verify -CAfile ssl/chain.pem ssl/cert.pem

# Test HTTPS endpoint
curl -v https://localhost:3000
```

---

**Certificate ID**: cert_HpIgSDGIvxvYI2dl9uArerAk  
**Status**: Ready for configuration  
**Next Step**: Add certificate files and test HTTPS configuration