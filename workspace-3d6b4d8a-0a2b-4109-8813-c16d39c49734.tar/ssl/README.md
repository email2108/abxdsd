# SSL Certificate Files

This directory contains SSL certificate files for HTTPS configuration.

## Certificate ID: cert_HpIgSDGIvxvYI2dl9uArerAk

## Files Required:
- `cert.pem` - SSL certificate
- `privkey.pem` - Private key
- `chain.pem` - Certificate chain
- `fullchain.pem` - Full certificate chain

## Steps to configure:
1. Add your SSL certificate files to this directory
2. Update the server configuration to use SSL
3. Test HTTPS configuration

## For Development:
You can generate a self-signed certificate using:
```bash
npm run ssl:generate
```

## For Production:
Use proper SSL certificates from Let's Encrypt or your certificate provider.